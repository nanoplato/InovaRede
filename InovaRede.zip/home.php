<?php
session_start();
include 'db/connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $email = $_POST['email'];
  $senha = $_POST['senha'];

  $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = ?");
  $stmt->bind_param("s", $email);
  $stmt->execute();
  $result = $stmt->get_result();
  $usuario = $result->fetch_assoc();

  if ($usuario && password_verify($senha, $usuario['senha'])) {
    $_SESSION['usuario_id'] = $usuario['id'];
    $_SESSION['nome'] = $usuario['nome'];
  } else {
    echo "Login inválido";
    exit;
  }
}

if (!isset($_SESSION['usuario_id'])) {
  header("Location: index.html");
  exit;
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>InovaRede - Feed</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
  <h3>Olá, <?php echo $_SESSION['nome']; ?>! <a href="logout.php" class="btn btn-sm btn-danger float-end">Sair</a></h3>
  <hr>
  <form action="post.php" method="post" enctype="multipart/form-data">
    <div class="mb-3">
      <textarea name="conteudo" class="form-control" placeholder="Compartilhe algo..." required></textarea>
    </div>
    <div class="mb-3">
      <input type="file" name="imagem" class="form-control">
    </div>
    <button type="submit" class="btn btn-primary">Postar</button>
  </form>
  <hr>
  <h4>Últimas postagens</h4>
  <?php
  $sql = "SELECT p.*, u.nome FROM posts p JOIN usuarios u ON p.usuario_id = u.id ORDER BY p.data_postagem DESC";
  $result = $conn->query($sql);
  while ($row = $result->fetch_assoc()) {
    echo "<div class='card mb-3'>";
    echo "<div class='card-body'>";
    echo "<h5>{$row['nome']}</h5>";
    echo "<p>{$row['conteudo']}</p>";
    if ($row['imagem']) {
      echo "<img src='uploads/{$row['imagem']}' class='img-fluid rounded'>";
    }
    echo "<small class='text-muted'>{$row['data_postagem']}</small>";
    echo "</div></div>";
  }
  ?>
</div>
</body>
</html>